-- Put yor transformer implementation in this file
module TransformerImpl where

import Definitions
-- import ReadP or Parsec

convert :: EGrammar -> EM Grammar
convert = undefined

lre :: Grammar -< EM Grammar
lre = undefined

lfactor :: Grammar -< EM Grammar
lfactor = undefined
