-- This is a wrapper module. Do not modify it
module Parser (parseSpec) where

import ParserImpl
