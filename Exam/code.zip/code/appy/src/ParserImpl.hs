-- Put yor parser implementation in this file
module ParserImpl where

import Definitions
-- import ReadP or Parsec

parseSpec :: String -> EM (Preamble, EGrammar)
parseSpec = undefined
